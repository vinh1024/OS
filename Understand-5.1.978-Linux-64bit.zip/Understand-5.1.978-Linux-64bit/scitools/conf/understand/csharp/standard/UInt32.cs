namespace System
{
   public struct UInt32
   {
   }
}
