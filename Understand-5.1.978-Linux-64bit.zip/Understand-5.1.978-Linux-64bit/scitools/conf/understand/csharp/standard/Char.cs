namespace System
{
   public struct Char
   {
   }
}
