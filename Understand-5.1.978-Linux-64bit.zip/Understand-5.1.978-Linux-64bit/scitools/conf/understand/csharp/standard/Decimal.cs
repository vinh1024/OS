namespace System
{
   public struct Decimal
   {
   }
}
