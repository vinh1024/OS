namespace System
{
   public struct Single
   {
   }
}
