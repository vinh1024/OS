namespace System
{
   public struct Boolean
   {
   }
}