namespace System
{
   public struct Int32
   {
   }
}