def dump(value, file, version): pass
def dumps(value, version): pass
def load(file): pass
def loads(string): pass
version = 2
