class array(object):
     #  Methods:
     
     def append(): pass
     def buffer_info(): pass
     def byteswap(): pass
     def count(): pass
     def extend(): pass
     def fromfile(): pass
     def fromlist(): pass
     def fromstring(): pass
     def index(): pass
     def insert(): pass
     def pop(): pass
     def read(): pass
     def remove(): pass
     def reverse(): pass
     def tofile(): pass
     def tolist(): pass
     def tostring(): pass
     def write(): pass
     
     
     #  Attributes:
     typecode = 0
     itemsize = 0
        
     #  Methods defined here:
     def __add__(): pass
     def __contains__(): pass
     def __copy__(): pass
     def __deepcopy__(): pass
     def __delitem__(): pass
     def __delslice__(): pass
     def __eq__(): pass
     def __ge__(): pass
     def __getattribute__(): pass
     def __getitem__(): pass
     def __getslice__(): pass
     def __gt__(): pass
     def __iadd__(): pass
     def __imul__(): pass
     def __iter__(): pass
     def __le__(): pass
     def __len__(): pass
     def __lt__(): pass
     def __mul__(): pass
     def __ne__(): pass
     def __reduce__(): pass
     def __repr__(): pass
     def __rmul__(): pass
     def __setitem__(): pass
     def __setslice__(): pass
     def append(): pass
     def buffer_info(): pass
     def byteswap(): pass
     def count(): pass
     def extend(): pass
     def fromfile(): pass
     def fromlist(): pass
     def fromstring(): pass
     def fromunicode(): pass
     def index(): pass
     def insert(): pass
     def pop(): pass
     def read(): pass
     def remove(): pass
     def reverse(): pass
     def tofile(): pass
     def tolist(): pass
     def tostring(): pass
     def tounicode(): pass
     def write(): pass
     #  Data and other attributes defined here:
     __new__ = 1

ArrayType = array
