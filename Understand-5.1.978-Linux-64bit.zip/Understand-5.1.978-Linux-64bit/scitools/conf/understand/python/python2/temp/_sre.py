# FUNCTIONS
def compile(): pass
def getcodesize(): pass
def getlower(): pass

# DATA
CODESIZE = 1
MAGIC = 1
copyright = ''
