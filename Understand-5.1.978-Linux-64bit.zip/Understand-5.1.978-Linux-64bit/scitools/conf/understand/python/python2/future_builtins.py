def ascii(arg): pass
def filter(pred, iterable): pass
def hex(arg): pass
def map(func, *iterables): pass
def oct(arg): pass
