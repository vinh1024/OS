def get_osfhandle(): pass
def getch(): pass
def getche(): pass
def getche(): pass
def getwch(): pass
def getwche(): pass
def heapmin(): pass
def kbhit(): pass
def locking(): pass
def open_osfhandle(): pass
def putch(): pass
def putwch(): pass
def setmode(): pass
def ungetch(): pass
def ungetwch(): pass
CRT_ASSEMBLY_VERSION = '9.0.21022.8'
LIBRARIES_ASSEMBLY_NAME_PREFIX = 'Microsoft.VC90'
LK_LOCK = 1
LK_NBLCK = 2
LK_NBRLCK = 4
LK_RLCK = 3
LK_UNLCK = 0
VC_ASSEMBLY_PUBLICKEYTOKEN = '1fc8b3b9a1e18e3b'


