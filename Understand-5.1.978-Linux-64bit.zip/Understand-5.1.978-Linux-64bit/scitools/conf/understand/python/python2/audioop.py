import exceptions
class error(exceptions.Exception):
     __weakref__ = []
def add(): pass
def adpcm2lin(): pass
def alaw2lin(): pass
def avg(): pass
def avgpp(): pass
def bias(): pass
def cross(): pass
def findfactor(): pass
def findfit(): pass
def findmax(): pass
def getsample(): pass
def lin2adpcm(): pass
def lin2alaw(): pass
def lin2lin(): pass
def lin2ulaw(): pass
def max(): pass
def maxpp(): pass
def minmax(): pass
def mul(): pass
def ratecv(): pass
def reverse(): pass
def rms(): pass
def tomono(): pass
def tostereo(): pass
def ulaw2lin(): pass
