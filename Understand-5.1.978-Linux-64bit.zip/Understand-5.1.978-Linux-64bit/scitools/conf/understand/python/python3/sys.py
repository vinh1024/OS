# Functions
def displayhook(): pass
def excepthook(): pass
def exc_info(): pass
def exit(): pass 
def getdlopenflags(): pass 
def getprofile(): pass 
def getrefcount(): pass 
def getrecursionlimit(): pass 
def getsizeof(): pass 
def gettrace(): pass 
def setcheckinterval(): pass 
def setdlopenflags(): pass 
def setprofile(): pass 
def setrecursionlimit(): pass 
def settrace(): pass 
# DATA
__stderr__ = 1
__stdin__ = 1
__stdout__ = 1
api_version = 1013
argv = ['write_help.py']
base_exec_prefix = r'C:\Python33'
base_prefix = r'C:\Python33'
builtin_module_names = ()
byteorder = 'little'
copyright = 'Copyright (c) 2001-2013 Python Software Foundati...ematis...'
dllhandle = 503316480
dont_write_bytecode = False
exec_prefix = r'C:\Python33'
executable = r'C:\Python33\python.exe'
flags = sys.flags()
float_info = sys.float_info()
float_repr_style = 'short'
hash_info = sys.hash_info()
hexversion = 50529008
implementation = namespace()
int_info = sys.int_info(bits_per_digit=30, sizeof_digit=4)
maxsize = 9223372036854775807
maxunicode = 1114111
meta_path = []
modules = {}
path = []
path_hooks = []
path_importer_cache = {}
platform = 'win32'
prefix = r'C:\Python33'
stderr = 1
stdin = 1
stdout = 1
thread_info = sys.thread_info(name='nt', lock=None, version=None)
version = ''
version_info = 1
warnoptions = []
winver = ''


